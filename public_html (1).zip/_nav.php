<?php
//Security Check
if (count(get_included_files()) == 1) exit("No direct script access allowed.");
?>
<!-- Navigation -->

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class=" container col-lg-4 col-sm-12 w-sm-100"><a class="navbar-brand" href="index.php"><img style="width:35%" src="./content/img/logo1.png" /> </a></div>
  
 
  <div class="  container   my-3 " >
    <ul class="navbar-nav d-flex flex-row w-100 justify-content-around " >
        
        <!--------------------------------------------------------reels----------------------------------->
      <a href="./_reels.php">
        <li class="nav-item   mr-5 my-3 d-lg-block d-none" style="color:black; font-weight:bold">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" height="20px" width="20px">
            <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" />
          </svg>
          Reel
        </li>
    
      </a>
      <a class="nav-link" href="./_reels.php " style="color:black; font-weight:bold;  padding-right :0.3rem">    <li class=" nav-item d-lg-none d-block " style="text-decoration:none">Reel</li></a>
      <!---------------------------------------------------------reels--------------------------------------->
   
   
      <!--------------------------------------------------------videos------------------------------------------->
      <a href="./_videos.php">
        <li class="nav-item  mr-5  my-3 d-lg-block d-none" style="color:black; font-weight:bold">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" height="20px" width="20px"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M0 128C0 92.7 28.7 64 64 64H320c35.3 0 64 28.7 64 64V384c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V128zM559.1 99.8c10.4 5.6 16.9 16.4 16.9 28.2V384c0 11.8-6.5 22.6-16.9 28.2s-23 5-32.9-1.6l-96-64L416 337.1V320 192 174.9l14.2-9.5 96-64c9.8-6.5 22.4-7.2 32.9-1.6z" />
          </svg> Video
        </li>
      </a>
      
      <a class="nav-link" href="./_videos.php" style="color:black; font-weight:bold">    <li class=" nav-item d-lg-none d-block " style="text-decoration:none">Videos</li></a>
            
            <!--------------------------------------------------------videos------------------------------------------->
            
            
            
            <!---------------------------------------------------------photos--------------------------------------------->
      <a href="./_photos.php">
        <li class="nav-item  mr-5 my-3 d-lg-block d-none" style="color:black; font-weight:bold">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" height="20px" width="20px"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M181.3 32.4c17.4 2.9 29.2 19.4 26.3 36.8L197.8 128h95.1l11.5-69.3c2.9-17.4 19.4-29.2 36.8-26.3s29.2 19.4 26.3 36.8L357.8 128H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H347.1L325.8 320H384c17.7 0 32 14.3 32 32s-14.3 32-32 32H315.1l-11.5 69.3c-2.9 17.4-19.4 29.2-36.8 26.3s-29.2-19.4-26.3-36.8l9.8-58.7H155.1l-11.5 69.3c-2.9 17.4-19.4 29.2-36.8 26.3s-29.2-19.4-26.3-36.8L90.2 384H32c-17.7 0-32-14.3-32-32s14.3-32 32-32h68.9l21.3-128H64c-17.7 0-32-14.3-32-32s14.3-32 32-32h68.9l11.5-69.3c2.9-17.4 19.4-29.2 36.8-26.3zM187.1 192L165.8 320h95.1l21.3-128H187.1z" />
          </svg> Photo
        </li>
      </a>
          
          
      <a class="nav-link" href="./_photos.php" style="color:black; font-weight:bold">    <li class=" nav-item d-lg-none d-block " style="text-decoration:none"> Photo</li></a>
            <!---------------------------------------------------------photos--------------------------------------------->
      
      <!----------------------------------------------------------IGTV-------------------------------------------------------->
      
      <a href="./_Igtv.php">
        <li class="nav-item mr-5  my-3  d-lg-block d-none" style="color:black; font-weight:bold">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" height="22px" width="22px"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M64 64V352H576V64H64zM0 64C0 28.7 28.7 0 64 0H576c35.3 0 64 28.7 64 64V352c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V64zM128 448H512c17.7 0 32 14.3 32 32s-14.3 32-32 32H128c-17.7 0-32-14.3-32-32s14.3-32 32-32z" />
          </svg>IGtv
        </li>
      </a>


      <a class="nav-link" href="./_Igtv.php" style="color:black; font-weight:bold">    <li class=" nav-item d-lg-none d-block " style="text-decoration:none">  IGtv</li></a>
<!-----------------------------------------------------------------IGTV--------------------------------------------------------------------->


<!---------------------------------------------------------------Carousel------------------------------------------------------------------->
      <a href="./_carosel.php">
        <li class="nav-item  my-3 d-lg-block d-none" style="color:black; font-weight:bold">

          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" height="20px" width ="20px"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M0 416c0 17.7 14.3 32 32 32l54.7 0c12.3 28.3 40.5 48 73.3 48s61-19.7 73.3-48L480 448c17.7 0 32-14.3 32-32s-14.3-32-32-32l-246.7 0c-12.3-28.3-40.5-48-73.3-48s-61 19.7-73.3 48L32 384c-17.7 0-32 14.3-32 32zm128 0a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM320 256a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm32-80c-32.8 0-61 19.7-73.3 48L32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l246.7 0c12.3 28.3 40.5 48 73.3 48s61-19.7 73.3-48l54.7 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-54.7 0c-12.3-28.3-40.5-48-73.3-48zM192 128a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm73.3-64C253 35.7 224.8 16 192 16s-61 19.7-73.3 48L32 64C14.3 64 0 78.3 0 96s14.3 32 32 32l86.7 0c12.3 28.3 40.5 48 73.3 48s61-19.7 73.3-48L480 128c17.7 0 32-14.3 32-32s-14.3-32-32-32L265.3 64z" />
          </svg>Carousel
        </li>
      </a>
      
      <a class="nav-link" href="./_carosel.php" style="color:black; font-weight:bold"><li class="nav-item d-lg-none d-block" style="text-decoration:none">Carousel</li></a>
<!------------------------------------------------------------------Carousel-------------------------------------------------------------------->


    </ul>

  
  </div>
</nav>