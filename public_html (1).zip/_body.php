<?php
//Security Check
if (count(get_included_files()) == 1) exit("No direct script access allowed.");
?>
<section class="features-icons bg-pink text-center text-white">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
          <div class="features-icons-icon d-flex">
            <i class="icon-like m-auto text-white"></i>
          </div>
          <h3>Supports every Video</h3>
          <p class="lead mb-0">Download any video in multiple qualities from Instagram.</p>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
          <div class="features-icons-icon d-flex">
            <i class="icon-info m-auto text-white"></i>
          </div>
          <h3>Carousel</h3>
          <p class="lead mb-0">Carousel videos and images are supported.</p>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="features-icons-item mx-auto mb-0 mb-lg-3">
          <div class="features-icons-icon d-flex">
            <i class="icon-energy m-auto text-white"></i>
          </div>
          <h3>Fast Downloads</h3>
          <p class="lead mb-0">Get lighting fast download speed without any limit.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!------------------------------content------------------------- -->
<div class="container">

  <h1 class="text-center my-5"> IGSnapInsta Instagram Video Downloader Feature </h1>
  <div class="row text-sm-center my-sm-5">
    <div class="col-lg-6 col-sm-12"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEeUjiWS7oAf8suOBk5BHxurU8LXtzCFW-ae3n8WRey5XZfX92Uh_6YrdkLE014soG5w0&usqp=CAU" /></div>
    <div class="col-lg-6 col-sm-12">
      <h3>Instagram Reel Download</h3>
      <p class="text-left">
        Find any interesting reel , want to share it with your friends
        who don't use Instagram , We, introduce IGSnapInsta , a tool
        which help you to download any reel just you have to copy the link ,
        You can do that by seeing <strong>How to Download</strong> section
        down below , and then the reel will be downloaded ,
        in your device for permanently.
      </p>
    </div>
  </div>
  <!----------------------------video downloader------------------------------>

  <div class="row text-sm-center my-sm-5">
    <div class="col-lg-6 col-sm-12">
      <h3>Instagram Video Download</h3>
      <p class="text-left">
        Having a confusion , choosing betweeen ,
        your favourite instagram video or do your important work , don't worry about
        that , we got you your back , just follow the <strong>how to download</strong> step
        and download your favourite video , to watch it later .
      </p>
    </div>

    <div class="col-lg-6 col-sm-12"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJ9avQe8PUakXG_ICPQagRQDqACerLahFjtw&usqp=CAU" />
    </div>
  </div>
  <!----------------------------video downloader------------------------------>

  <!---------------------------igtv   downloader--------------------------->
  <div class="row my-5 text-sm-center ">
    <div class="col-lg-6 col-sm-12">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrbRghKuwERPbVE8wZbDCRWD4H-YtOl8NcXg&usqp=CAU" />
    </div>
    <div class="col-lg-6 c0l-sm-12">
      <h3>Instagram IGTV Download</h3>
      <p class="text-left">
        IGTV are basically long videos , where your favourite celeberity ,
        or your favourite instagram influencer comes to share something ,
        but you are in between a metting or doing a important task , Don't worry ,
        we got your back , just follow the <strong>how to download</strong> part , and download your
        favourite IGTV video and watch it later.
      </p>
    </div>
  </div>
  <!---------------------------igtv   downloader--------------------------->


  <!---------------------------Photo  downloader--------------------------->
  <div class=" row my-5 text-sm-center">
    <div class="col-lg-6 col-sm-12">
      <h3 >Instagram Photo Download</h3>
      <p class="text-left">
        Your favourite person just posted a photo on Instagram , but you want to see that photo anytime whe you want to ,
        Don't worry we got your back , just follow the <b>How to download</b> section , and sownload the photo which you want to .
      </p>
    </div>

    <div class="col-lg-6 col-sm-12"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpACQ5p4-C7qpOF8ICEHFC4o1YzoHPdfCgUw&usqp=CAU" />
    </div>
  </div>
  <!---------------------------photo   downloader--------------------------->

  </section>
</div>

<!------------------------------content------------------------- -->

<!-- fb downlaoder -->
<section class="text-center container ">
  <h1>Want To Use Our Other Platform?!! </h1>
  <div class="row align-lg-center">


    <div class="col-lg-6 mx-auto">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwn_yaeUUWyGw6jv8s1YwbN8cwkWyDQwDQaw&usqp=CAU" />
      <div>
        <p>Use our facebook video downloader </p>
     
          <a href="https://igstudioz.com/" target="_blank" 
          style="background: linear-gradient(115deg, #f9ce34, #ee2a7b, #6228d7);
        border:none;
        border-radius:20px;
        padding:0.7rem;
        color:white">
            Go there!!</button>
        </a>
      </div>
    </div>
  </div>
</section>


<!-- fb downlaoder -->




<section class="instructions text-center bg-light">
  <div class="container">
    <h2 class="mb-5 text-pink">How to Download?</h2>
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <ul class="list-group text-left text-secondary mb-5">
          <li class="list-group-item">
            <span class="badge badge-dark badge-pill mr-2">1.</span>Open the video you'd like to download from Instagram.
          </li>
          <li class="list-group-item">
            <span class="badge badge-dark badge-pill mr-2">2.</span>Click on three dots and choose Copy Link.
          </li>
          <li class="list-group-item">
            <span class="badge badge-dark badge-pill mr-2">3.</span>Paste the url above and hit submit button.
          </li>
          <li class="list-group-item">
            <span class="badge badge-dark badge-pill mr-2">4.</span>Click on the download button to start downloading.
          </li>
        </ul>
       
      </div>
    </div>
  </div>
</section>



<!-- Footer -->
<footer class="footer bg-dark footer-white-links">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 h-100 text-center text-lg-left  mb-5 ">
        <a href="index.php"> <img style="width:30%" src="./content/img/logo1.jpg" /> </a>
        <p class="muted " style="color:white;"> Made  by <a href="https://grandeurnet.com/">Grandeur Net</a></p>
      </div>
      
      <div class="col-lg-4 text-lg-left text-white   ">
        <ul style="width:100%; color:white">
          <a href="./_photos.php">
            <li>Instagram Photo Downloader</li>
          </a>
          <a href="./_reels.php">
            <li>Instagram Reel Downloader</li>
          </a>
          <a href="./_videos.php">
            <li>Instagram Video Downloader</li>
          </a>
          <a href="./_carosel.php">
            <li>Instagram Carousel Downloader</li>
          </a>
          <a href="./_Igtv.php">
            <li>Instagram IGTV Downloader</li>
          </a>
          <a href="https://igstudioz.com">
            <li>Facebook video downloader from IGSTUDIOZ</li>
          </a>
        </ul>
      </div>

      <div class="col-lg-2 text-lg-left text-white   ">
        <ul style="color:white">
          <a href="./contact.php">
            <li>Contact</li>
          </a>
          <a href="./privacyPolicy.php">
            <li>Privacy Policy</li>
          </a>
          <a href="./termsAndCondition.php">
            <li>Terms n Conditions</li>
          </a>
        </ul>
      </div>
       
    
    </div>
  </div>
  <hr style="background:white">
  <h6 class="text-center" style="color:white">We are not affiliated with Instagram or Meta</h6>
  <p class="text-center" style="color:white">2023-2024 IGSnapInsta</p>
</footer>

<!-- Bootstrap core JavaScript -->
<script src="content/js/jquery.min.js"></script>
<script src="content/js/bootstrap.bundle.min.js"></script>