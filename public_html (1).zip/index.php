<?php include("config.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="<?php echo $config["description"]; ?>">
  <meta name="author" content="">
<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Bootstrap JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

  <title>Instagram Downloader<?php echo $config["tag-line"]; ?></title>

  <!-- Bootstrap core CSS -->
  <link href="content/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="content/css/landing-page.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <?php echo $config["ga"]; ?>
  <script src="https://kit.fontawesome.com/95b9f531f4.js" crossorigin="anonymous"></script>
</head>

<body>

  <?php include '_nav.php'; ?>

  <section class="features-icons bg-light text-center mb-5"
  style="background: linear-gradient(115deg, #f9ce34, #ee2a7b, #6228d7);"
  >
    <div class="container">
      <div class="row">
       
        <div class="col-md-10 offset-md-1">
          
          <h2 id="dynamicText" class="text-center mt-4 mb-4">Instagram Video Downloader </h2>
          <h3>Download Videos, Reels, Photos, IGTV, carousel from Instagram</h3>
          <form method="POST" action="javascript:void(0)" id="form">
            <div class="download-input mb-4">
              <div class="input-group input-group-lg">
                <input type="text" id="url" class="form-control"    placeholder="Paste link here!">
                <div class="input-group-append">
                  <button class="btn  btn-sm" id="form_submit" type="submit" style="background :#41C9E2;color:white">
                    <!--<i class="fa fa-download" aria-hidden="true" style="color:white;background:transparent;margin: 4px;"></i>-->
                Download
                  </button>
              <button class="btn btn-blue ml-1"  style="background :#41C9E2;color:white" type="button"  onclick="clearInput()"> Clear</i></button>

                </div>

              </div>

            </div>
          </form>

          <i class="fa fa-circle-o-notch fa-3x fa-spin mb-4" id="loading-ajax" style="display: none;"></i>

         

          <div id="downloadbox"></div>

        </div>
      </div>
    </div>
  </section>

  <?php include '_body.php'; ?>
  <script src="content/js/ajax.js"></script>
<script>
 
    function clearInput() {
        // Select the input field by its ID
    
        var inputField = document.getElementById("url");
        
        // Set the value of the input field to an empty string
        inputField.value = "";
    }
</script>

  </script>
</body>

</html>