<?php include("./config.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="<?php echo $config["description"]; ?>">
  <meta name="author" content="">

  <title>Instagram Downloader<?php echo $config["tag-line"]; ?></title>

  <!-- Bootstrap core CSS -->
  <link href="./content/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="./content/css/landing-page.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <?php echo $config["ga"]; ?>
  <script src="https://kit.fontawesome.com/95b9f531f4.js" crossorigin="anonymous"></script>
</head>

<body>

  <?php include '_nav.php'; ?>

  <section class="features-icons bg-light text-center" style="background: linear-gradient(115deg, #f9ce34, #ee2a7b, #6228d7);">
    <div class="container">
      <div class="row">
      
        <div class="col-md-10 offset-md-1">
          <div class="col-md-6 mx-auto">
            <!-- //img section  -->
          </div>
          <h2 class="text-center mt-4 mb-4">Instagram Carousel Downloader </h2>
          <form method="POST" action="javascript:void(0)" id="form">
            <div class="download-input mb-4">
              <div class="input-group input-group-lg">
                <input type="text" id="url" class="form-control" placeholder="Paste link here!">
                <div class="input-group-append">
                  <button class="btn btn-blue" id="form_submit" type="submit" style="background:#41C9E2">
                    Download
                  </button>
                  <button class="btn btn-blue ml-1" style="background:#41C9E2" type="button" onclick="clearInput()"> Clear</i></button>
                </div>
              </div>
            </div>
          </form>

          <i class="fa fa-circle-o-notch fa-3x fa-spin mb-4" id="loading-ajax" style="display: none;"></i>

         

          <div id="downloadbox"></div>

        </div>
      </div>
    </div>
  </section>


  <div class="container">
    <h4 class="my-5">Welcome to IGSnapInsta , your go-to destination for downloading Instagram carousles effortlessly ,
        finding a perfect story telling carousels in your feed , you realize that you don't
      have enough time to watch all the carousel's item ,
      <br /> Don't worry IGSnapInsta got your back just follow the How to download section , ang enjoy them offline anytime , anywhere

    </h4>
    <div class="row">
      <div class="col-lg-6 col-sm-12 text-center my-5">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8e-wDbwbI6aMrDBIygHetg-esWRgMjxu6Tg&usqp=CAU">
      </div>
      <div class="col-lg-6 col-sm-12 my-5">
        <h4>Silent features of IGSnapInsta</h4>
        <p><strong>Effortless Downloading</strong>:IGSnapInsta simplifies the process of
          downloading Instagram carousels . No more hassle or
          <br /> frustration - just swift and straightforward downloads at your fingertips
        </p>
        <p><strong>Preserve Engaging Content :</strong>Capture and preserve the captivating
          carousel posts that catch your eye on Instagram. Whether it's stunning photography,
          insightful infographics, or entertaining slideshows, IGSnapInsta ensures you never miss 
          out on the content that matters most to you. </p>
          <p><strong>User Friendly Interface:</strong>
          IGSnapInsta features a user-friendly interface designed for seamless navigation and
           effortless downloading. Whether you're a tech-savvy enthusiast or a casual user, our 
          platform makes downloading Instagram carousels a breeze for everyone.
        </p>


      </div>
      <div>


      </div>


    </div>
  </div>


  <?php include './_body.php'; ?>
  <script src="./content/js/ajax.js"></script>
  <script>
    function clearInput() {
      // Select the input field by its ID

      var inputField = document.getElementById("url");

      // Set the value of the input field to an empty string
      inputField.value = "";
    }
  </script>
</body>

</html>