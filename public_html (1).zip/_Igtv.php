<?php include("./config.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="<?php echo $config["description"]; ?>">
  <meta name="author" content="">

  <title>Instagram Downloader<?php echo $config["tag-line"]; ?></title>

  <!-- Bootstrap core CSS -->
  <link href="./content/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="./content/css/landing-page.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <?php echo $config["ga"]; ?>
  <script src="https://kit.fontawesome.com/95b9f531f4.js" crossorigin="anonymous"></script>
</head>

<body>

<?php include '_nav.php'; ?>

  <section class="features-icons bg-light text-center"
  style="background: linear-gradient(115deg, #f9ce34, #ee2a7b, #6228d7);">
    <div class="container">
      <div class="row">
       
        <div class="col-md-10 offset-md-1">
          <div class="col-md-6 mx-auto">
           
          </div>
          <h2 class="text-center mt-4 mb-4"> Instagram IGTV Downloader </h2>
          <form method="POST" action="javascript:void(0)" id="form">
            <div class="download-input mb-4">
              <div class="input-group input-group-lg">
                <input type="text" id="url" class="form-control" placeholder="Paste link here!">
                <div class="input-group-append">
                  <button class="btn btn-blue" id="form_submit" type="submit" style="background:#41C9E2">
                    Download
                  </button>
                  <button class="btn btn-blue ml-1" style="background:#41C9E2"  type="button"  onclick="clearInput()"> Clear</i></button>
                </div>
              </div>
            </div>
          </form>

          <i class="fa fa-circle-o-notch fa-3x fa-spin mb-4" id="loading-ajax" style="display: none;"></i>


          <div id="downloadbox"></div>

        </div>
      </div>
    </div>
  </section>

  <h3 class="text-lg-center  my-5 text-sm-center">
    Are you tired of being unable to save your favourite Instagram  IGTV for offline viewing?<br/>
    Don't worry ! IGSnapInsta is your ultimate solution for effortlessly downloading
    Instagram  post directly to your device .
  </h3>

<div class="container">
  <div class="row">
    <div class="col-lg-6 col-sm-12">
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTOTIKoYnqiP7F6_05Ysy57LOmB0ceRW0HBag&usqp=CAU" />
</div>
    <div class="w-50 my-5 col-lg-6 col-sm-12 ">
      <h5>Silent Feature of IGSnapInsta:</h5>
      <p><strong>Seamless Downloading :</strong>
        With IGSnapInsta , downloading Instagram IGTV is a breeze.
        IGSnapInsta provides the best seamless downloading speed , like never before
      </p>
      <p><strong>Instant Accessibility :</strong>
        whether it is the IGTV of the last day of the school , or of you
        loved ones ,IGSnapInsta allows you to save Instagram post directly to your device for instant Accessibility
        even when you're offline.
      </p>
      <p><strong>No Limits :</strong>
        Unlike other platforms ,IGSnapInsta have almost no restriction
        of downloading any number of IGTV videos.
      </p>
      <p><strong>Privacy Protection : </strong>Your privacy and security are
        our top priorities.
        IGSnapInsta ensures that your
        personal information remains secure
        and confidential throughout the downloading process.</p>
    </div>
  </div>
  </div>

  <?php include './_body.php'; ?>
  <script src="./content/js/ajax.js"></script>
  <script>
  function clearInput() {
        // Select the input field by its ID
         
        var inputField = document.getElementById("url");
        
        // Set the value of the input field to an empty string
        inputField.value = "";
    }
    </script>
</body>

</html>