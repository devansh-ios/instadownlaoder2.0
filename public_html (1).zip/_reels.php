<?php include("./config.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="<?php echo $config["description"]; ?>">
  <meta name="author" content="">

  <title>Instagram Downloader<?php echo $config["tag-line"]; ?></title>

  <!-- Bootstrap core CSS -->
  <link href="./content/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="./content/css/landing-page.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <?php echo $config["ga"]; ?>
  <script src="https://kit.fontawesome.com/95b9f531f4.js" crossorigin="anonymous"></script>
</head>

<body>

  <?php include '_nav.php'; ?>

  <section class="features-icons bg-light text-center"
  style="background: linear-gradient(115deg, #f9ce34, #ee2a7b, #6228d7);">
    <div class="container">
      <div class="row">
       
        <div class="col-md-10 offset-md-1">
          <div class="col-md-6 mx-auto">
            
          </div>
          <h2 class="text-center mt-4 mb-4">Instagram Reel Downloader </h2>
          <form method="POST" action="javascript:void(0)" id="form">
            <div class="download-input mb-4">
              <div class="input-group input-group-lg">
                <input type="text" id="url" class="form-control" placeholder="Paste link here!">
                <div class="input-group-append">
                  <button class="btn btn-blue" id="form_submit" type="submit" style="background:#41C9E2">
          Download
                  </button>
                  <button class="btn btn-blue ml-1"  type="button" style="background:#41C9E2"  onclick="clearInput()"> Clear</i></button>
                </div>
              </div>
            </div>
          </form>

          <i class="fa fa-circle-o-notch fa-3x fa-spin mb-4" id="loading-ajax" style="display: none;"></i>

       

          <div id="downloadbox"></div>

        </div>
      </div>
    </div>
  </section>
  <h4 class="text-lg-center my-5">Are you tired of missing out on your favourite instagram reels because you can't
        watch them offline or can't show your best friend a 'relatable' reel ,
        IGSnapInsta is here to revolutionize the way you can enjoy Instagram content.


      </h4>
  <section class="container  my-5   d-flex justify-content-lg-between align-items-center">
 <div class="row">
    <div class="col-lg-6 col-sm-12 my-5">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0vwS82USii2U8SFivyY_B5MZUzDK_4UuqlQ&usqp=CAU" />
    </div>
    <div class=" col-lg-6 col-sm-12 my-5  ">
     
      
        <h6 style="text-decoration:underline">
          Silent feature of using IGSnapInsta
        </h6>
        <p><strong> Effortless Reel Downloads</strong> :- IGSnapInsta
          allows you to download any Reel
          effortlessly by simply entering the link</p>
        <p><strong>Privacy Protection:-</strong>We value your privacy and security.
          IGSnapInsta ensures that your personal
          information remains safe and confidential at all times.</p>
        <p><strong>Free and Unlimited Download</strong>:- IGSnapInsta provides the free and ultimate download
          of any type of reels that you want to download.</p>
          <p> <strong>User-Friendly Interface</strong> Our platform is designed with simplicity in mind. You don't need to be a tech expert to use IGSnapInsta.
             Just enter the Reel link, and you're good to go!</p>
     
    </div>
 </div>
  </section>

  <?php include './_body.php'; ?>
  <script src="./content/js/ajax.js"></script>
  <script>
  function clearInput() {
        // Select the input field by its ID
     
        var inputField = document.getElementById("url");
        
        // Set the value of the input field to an empty string
        inputField.value = "";
    }
    </script>
</body>

</html>