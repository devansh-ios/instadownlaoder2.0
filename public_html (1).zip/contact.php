<?php include("./config.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="<?php echo $config["description"]; ?>">
  <meta name="author" content="">

  <title>Instagram Downloader<?php echo $config["tag-line"]; ?></title>

  <!-- Bootstrap core CSS -->
  <link href="./content/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="./content/css/landing-page.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <?php echo $config["ga"]; ?>
  <script src="https://kit.fontawesome.com/95b9f531f4.js" crossorigin="anonymous"></script>
</head>

<body>

  <?php include '_nav.php'; ?>

<div class="container my-5">
    <p>Are you interested in learning further details about the ways in which our assistance can benefit you ?
        <br/> Feel free to reach out to us wihtout any hesitation.

    </p>
    <p>Contact us by email : <a href="mailto:IGSnapInsta0555@gmail.com">IGSnapInsta0555@gmail.com</a></p>
</div>

  <script src="./content/js/ajax.js"></script>

</body>

</html>